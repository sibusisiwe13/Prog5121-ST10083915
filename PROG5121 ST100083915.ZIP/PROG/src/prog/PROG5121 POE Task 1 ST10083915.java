
package prog;

import javax.swing.JOptionPane;
import java.util. *;
import java.util.regex.Pattern;

S


public class PROG {

    
    public static void main(String[] args) {
        String firstname;
        String lastname;
        String username;
        String passwaord;
                
        JOptionPane.showMessageDialog(null, "Enter your first name");
        JOptionPane.showInputDialog("");
        JOptionPane.showMessageDialog(null, "Enter your last name");
        JOptionPane.showInputDialog("");
        JOptionPane.showMessageDialog(null, "Enter username");
        JOptionPane.showInputDialog("");
        JOptionPane.showMessageDialog(null, "Enter your passwaord");
        JOptionPane.showInputDialog("");
        
        String input = "username";
        
        
        
        
        if(isWord(input))
        {
          JOptionPane.showMessageDialog(null, "Username is captured successfully"); 
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted,"
                    + " please ensure that your username contains an underscore and is no more than 5 characters in length");
        }
            
    }
    
    public static boolean isWord(String in){
        return Pattern.matches("(a-zA-Z)+ underscore+ not > 5 characters", in);
        
        
    public static boolean val.Pass(String password) {
       if(password.length() > 8)
       {
           JOptionPane.showMessageDialog(null, "Password successfully captured");
       }
       else
       {
           JOptionPane.showMessageDialog(null, "password is not correctly formatted,"
                   + "please ensure that the password contains at least 8 "
                   + "characters,a captail letter, a number and a special charater");
          
       }
   
} 
    public static boolean checkPass(String password)
    {
        boolean hasNum = false; boolean hasCap = false; boolean hasLow = false; 
        boolean hasChar = false;
        for(int i=0;i < password.length(); i++)
        
        
        {
            char c = password.charAt(1);
            if(Character.isDigit(c));
            {
                hasNum = true;
            }
             
            if (Character.isUpperCase(c))
                    {
                    hasCap = true;
                    }
            else if (Character.isLowerCase(c))
                    {
                    hasLow = true;
                    }
            if(hasNum && hasCap && hasLow)
            {
                return true;
            }
            return false;
            
                
        
            
            
        }
    }

        
    
        
        
        
   
        
        
        
        
       
        
        
    }
    
}
